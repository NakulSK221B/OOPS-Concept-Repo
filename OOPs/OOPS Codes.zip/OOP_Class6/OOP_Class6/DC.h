#pragma once
#include "Base.h"
class DC :
    public Base
{
public:
    void printHello();

    void printHelloClass();

    void printHi();
};

