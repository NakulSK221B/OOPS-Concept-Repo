#include "Base.h"
#include <iostream>

using namespace std;

void Base::printHello() {

	cout << endl << "Base::printHello" << endl;
}

void Base::printHelloClass(){

	cout << endl << "Base::printHelloClass" << endl;
}