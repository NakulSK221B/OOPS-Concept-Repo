#include "DC.h"
#include <iostream>

using namespace std;


void DC::printHello() {

	cout << endl << "DC::printHello" << endl;
}

void DC::printHelloClass() {

	cout << endl << "DC::printHelloClass" << endl;
}

void DC::printHi() {

	cout << endl << "DC::printHi" << endl;
}