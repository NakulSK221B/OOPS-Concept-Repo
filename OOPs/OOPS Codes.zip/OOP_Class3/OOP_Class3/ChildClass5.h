#pragma once
#include "ChildClass1.h"
class ChildClass5 : public ChildClass1
{
};

