#include "derived2.h"
#include <iostream>

using namespace std;

derived2::derived2() {

	cout << "derived2::derived2" << endl;
}