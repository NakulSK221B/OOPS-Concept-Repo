#include "base.h"
#include <iostream>

using namespace std;

base::base() {

	cout << "base::base" << endl;
}