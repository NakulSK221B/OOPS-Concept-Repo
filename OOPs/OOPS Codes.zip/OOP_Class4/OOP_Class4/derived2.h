#pragma once
#include "base.h"
class derived2 :
    virtual public base
{
public:
    int kk;

    derived2();
};

