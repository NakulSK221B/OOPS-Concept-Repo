#include "derived1.h"
#include <iostream>

using namespace std;

derived1::derived1() {

	cout << "derived1::derived1" << endl;
}