#include "derived3.h"
#include <iostream>

using namespace std;

derived3::derived3() {

	cout << "derived3::derived3" << endl;
}