#pragma once
#include "base.h"
class derived1 :
    virtual public base
{
public:
    int jj;
    derived1();
};

