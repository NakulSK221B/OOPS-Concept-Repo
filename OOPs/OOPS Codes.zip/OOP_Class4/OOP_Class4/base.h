#pragma once
class base
{
public:
	int ii;

	base();
};

