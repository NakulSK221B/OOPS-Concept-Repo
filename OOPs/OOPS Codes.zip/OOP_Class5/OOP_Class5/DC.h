#pragma once
#include "BaseClass.h"
class DC : private BaseClass
{
public:
	BaseClass::ii;
};

