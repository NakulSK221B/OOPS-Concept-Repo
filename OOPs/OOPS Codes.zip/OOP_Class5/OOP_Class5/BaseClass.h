#pragma once
class BaseClass
{
public:
	int ii;
};

