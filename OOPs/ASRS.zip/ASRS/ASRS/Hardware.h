#pragma once
#include <string>

using namespace std;

class Hardware
{
public:
	Hardware();

	~Hardware();

	void printDetails();

	string getHarwareDetails();
};

